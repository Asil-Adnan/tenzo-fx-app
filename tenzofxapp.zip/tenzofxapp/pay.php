<?php
// Tenzo FX - Payment (Light Neumorphic)
require_once 'auth_check.php';
require_once 'db.php';
check_auth(); // Must be logged in

$is_active = (isset($_SESSION['user_status']) && $_SESSION['user_status'] === 'active');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Activation - Tenzo FX</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script>
        // Poll for activation status every 5 seconds (Only if not active)
        <?php if (!$is_active): ?>
        setInterval(function() {
            fetch('session_check.php')
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'active') {
                        window.location.reload();
                    }
                });
        }, 5000);
        <?php endif; ?>

        function copyToClipboard() {
            const address = "TN4fWiMYnTttRCrccY87pSKNF8ferCrwVP";
            navigator.clipboard.writeText(address).then(() => {
                const btn = document.getElementById('copyBtn');
                const originalText = btn.innerHTML;
                btn.innerHTML = '<span class="text-xs font-bold text-green-500">COPIED</span>';
                setTimeout(() => {
                    btn.innerHTML = originalText;
                }, 2000);
            });
        }
    </script>
    <style>
         body { font-family: 'Outfit', sans-serif; background-color: #ecf0f3; color: #4a5568; }
        .neu-card { background: #ecf0f3; box-shadow: 9px 9px 16px rgb(163,177,198,0.6), -9px -9px 16px rgba(255,255,255, 0.5); border-radius: 20px; }
        .neu-inset { background: #ecf0f3; box-shadow: inset 5px 5px 10px #d1d9e6, inset -5px -5px 10px #ffffff; border-radius: 12px; }
        .neu-btn { background: #ecf0f3; box-shadow: 6px 6px 10px 0 rgba(163,177,198, 0.7), -6px -6px 10px 0 rgba(255,255,255, 0.8); border-radius: 12px; transition: all 0.2s ease; color: #673ee5; cursor: pointer; }
        .neu-btn:hover { transform: translateY(-2px); box-shadow: 8px 8px 12px 0 rgba(163,177,198, 0.7), -8px -8px 12px 0 rgba(255,255,255, 0.8); }
        .neu-btn:active { transform: translateY(0); box-shadow: inset 4px 4px 8px 0 rgba(163,177,198, 0.7), inset -4px -4px 8px 0 rgba(255,255,255, 0.8); }
        .text-accent { color: #673ee5; }
    </style>
</head>
<body class="flex flex-col items-center justify-center min-h-screen p-4 gap-8">
    
    <!-- Separate Logo Container -->
    <div class="neu-card p-4 rounded-2xl flex items-center justify-center">
        <img src="tenzofxlogo.png" alt="Tenzo FX" class="h-10 w-auto">
    </div>

    <div class="neu-card w-full max-w-2xl p-10 text-center relative overflow-hidden">
        
        <!-- Titles Section 1 -->
        <div class="mb-8">
            <h1 class="text-2xl font-bold text-slate-700 mb-1"><?php echo $is_active ? 'Add Deposit' : 'Account Activation'; ?></h1>
            <p class="text-sm text-[#673ee5] font-bold"><?php echo $is_active ? 'Complete payment to increase your investment' : 'Complete payment to access the Tenzo FX Dashboard'; ?></p>
        </div>

        <!-- Titles Section 2 -->
        <div class="mb-6">
            <h2 class="text-xl font-bold text-slate-500 mb-1">Pay using USDT</h2>
            <p class="text-xs text-slate-400 font-bold uppercase tracking-wider">fast payment using any cryptowallet</p>
        </div>

        <!-- Payment Details -->
        <div class="flex items-center justify-center space-x-12 mb-8">
            <div class="flex flex-col">
                 <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Currency</span>
                 <span class="text-sm font-bold text-slate-700">USDT (Tether)</span>
            </div>
            <div class="flex flex-col">
                 <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Network</span>
                 <span class="text-sm font-bold text-slate-700">TRON (TRC20)</span>
            </div>
        </div>

        <!-- Wallet Address (Prominent) -->
        <div class="neu-card p-6 mb-8 border-2 border-[#673ee5] bg-[#673ee5]/5 shadow-lg transform scale-105">
             <label class="text-xs font-bold text-[#673ee5] uppercase tracking-widest mb-3 block">Wallet Address</label>
             <div class="flex flex-col md:flex-row items-center justify-center gap-3">
                 <code class="text-base font-bold font-mono text-slate-800 break-all select-all">TN4fWiMYnTttRCrccY87pSKNF8ferCrwVP</code>
                 <button id="copyBtn" onclick="copyToClipboard()" class="neu-btn px-6 py-3 text-xs font-bold uppercase tracking-wider hover:bg-[#673ee5] hover:text-white w-full md:w-auto transition-colors">
                     Copy
                 </button>
             </div>
        </div>

        <!-- QR Code -->
        <div class="flex flex-col items-center mb-8">
             <p class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">or scan the wallet QR</p>
             <div class="neu-inset p-4 inline-block">
                 <img src="qrcode.png" alt="USDT QR Code" class="w-40 h-40 mix-blend-multiply opacity-90 rounded-lg transform scale-95 origin-center"> 
             </div>
             <p class="mt-4 text-[10px] font-bold text-slate-400 max-w-xs mx-auto leading-relaxed">
                 copy the wallet address from QR Scanner and use for TRC20 payment
             </p>
        </div>

        <div class="flex items-center justify-center space-x-3 mb-6">
            <span class="relative flex h-3 w-3">
              <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
              <span class="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
            </span>
            <span class="text-xs font-bold text-slate-500 animate-pulse uppercase tracking-wide">Only Proceed if you have made the payment and have proof (transaction hash) </span>
        </div>
        
        <a href="dashboard.php<?php echo $is_active ? '?action=submit_deposit' : ''; ?>" class="neu-btn block w-full py-4 text-sm font-bold uppercase tracking-widest text-[#673ee5]">
            My Payment is Complete
        </a>

    </div>
</body>
</html>
