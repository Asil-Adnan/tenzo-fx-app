<?php
/**
 * Tenzo FX - Database Connection
 * Using PDO for secure database interactions.
 */

// Database Configuration
// defined('DB_HOST') OR define('DB_HOST', 'localhost');
// defined('DB_USER') OR define('DB_USER', 'root'); // Default for local, change for production
// defined('DB_PASS') OR define('DB_PASS', '');     // Default for local, change for production
// defined('DB_NAME') OR define('DB_NAME', 'tenzofx_db');

$host = 'localhost';
$db   = 'tenzofx_db';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    // In production, log this error instead of showing it
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
    // die("Database Connection Failed.");
}

// Function to sanitize input
function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}
?>
