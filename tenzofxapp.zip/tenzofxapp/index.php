<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tenzo FX - Premium Trading Platform</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { 
            font-family: 'Outfit', sans-serif; 
            background-color: #ecf0f3; 
            color: #4a5568; 
        }
        
        /* Light Neumorphic Utilities */
        .neu-card {
            background: #ecf0f3;
            box-shadow: 9px 9px 16px rgb(163,177,198,0.6), 
                       -9px -9px 16px rgba(255,255,255, 0.5);
            border-radius: 20px;
        }
        .neu-inset {
             background: #ecf0f3;
             box-shadow: inset 5px 5px 10px #d1d9e6, 
                        inset -5px -5px 10px #ffffff;
             border-radius: 12px;
        }
        .neu-btn {
            background: #ecf0f3;
            box-shadow: 6px 6px 10px 0 rgba(163,177,198, 0.7), 
                       -6px -6px 10px 0 rgba(255,255,255, 0.8);
            border-radius: 12px;
            transition: all 0.2s ease;
            color: #673ee5;
        }
        .neu-btn:hover {
            transform: translateY(-2px);
            box-shadow: 8px 8px 12px 0 rgba(163,177,198, 0.7), 
                       -8px -8px 12px 0 rgba(255,255,255, 0.8);
        }
        .neu-btn:active {
            transform: translateY(0);
            box-shadow: inset 4px 4px 8px 0 rgba(163,177,198, 0.7), 
                       inset -4px -4px 8px 0 rgba(255,255,255, 0.8);
        }
        .text-accent { color: #673ee5; }
    </style>
</head>
<body class="min-h-screen flex flex-col">
    <!-- Navbar -->
    <nav class="sticky top-0 z-50 bg-[#ecf0f3]/95 backdrop-blur-sm border-b border-white/20">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-20">
                <div class="flex items-center">
                    <img class="h-10 w-auto drop-shadow-md" src="tenzofxlogo.png" alt="Tenzo FX">
                </div>
                <div class="flex items-center space-x-4">
                    <a href="login.php" class="text-slate-500 hover:text-[#673ee5] font-bold text-sm px-4">Log In</a>
                    <a href="register.php" class="neu-btn px-6 py-2.5 text-xs font-bold uppercase tracking-wider text-[#673ee5]">Sign Up</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <main class="flex-grow flex items-center justify-center p-6 py-20">
        <div class="max-w-5xl mx-auto text-center">
            <h1 class="text-5xl md:text-8xl font-extrabold text-slate-800 mb-8 tracking-tighter leading-tight text-shadow-sm">
                Trading, <br><span class="text-[#673ee5]">Redefined.</span>
            </h1>
            <p class="text-xl md:text-2xl text-slate-500 mb-12 max-w-3xl mx-auto font-light">
                Experience the next generation of financial markets with Tenzo FX. <br class="hidden md:block">
                Zero latency, premium liquidity, and institutional-grade security.
            </p>
            <div class="flex flex-col md:flex-row justify-center items-center space-y-4 md:space-y-0 md:space-x-8">
                <a href="register.php" class="neu-btn px-12 py-5 text-lg font-bold uppercase tracking-widest text-[#673ee5] min-w-[200px]">
                    Start Trading
                </a>
                <a href="login.php" class="neu-inset px-12 py-5 text-lg font-bold uppercase tracking-widest text-slate-500 hover:text-[#673ee5] transition-colors min-w-[200px]">
                    Member Login
                </a>
            </div>
            
            <!-- Features Grid -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mt-24 text-left">
                <div class="neu-card p-10 hover:-translate-y-2 transition-transform duration-300">
                    <div class="h-14 w-14 neu-inset rounded-full flex items-center justify-center mb-6 text-[#673ee5]">
                        <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
                    </div>
                    <h3 class="font-bold text-xl text-slate-700 mb-3">Lightning Fast</h3>
                    <p class="text-base text-slate-500 leading-relaxed">Ultra-low latency execution designed for high-frequency trading strategies and instant order matching.</p>
                </div>
                <div class="neu-card p-10 hover:-translate-y-2 transition-transform duration-300">
                    <div class="h-14 w-14 neu-inset rounded-full flex items-center justify-center mb-6 text-[#673ee5]">
                         <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg>
                    </div>
                    <h3 class="font-bold text-xl text-slate-700 mb-3">Secure Vault</h3>
                    <p class="text-base text-slate-500 leading-relaxed">Your assets are protected by enterprise-grade encryption, multi-signature wallets, and 98% cold storage.</p>
                </div>
                <div class="neu-card p-10 hover:-translate-y-2 transition-transform duration-300">
                     <div class="h-14 w-14 neu-inset rounded-full flex items-center justify-center mb-6 text-[#673ee5]">
                        <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>
                     </div>
                    <h3 class="font-bold text-xl text-slate-700 mb-3">Deep Analytics</h3>
                    <p class="text-base text-slate-500 leading-relaxed">Access advanced charting tools, real-time market insights, and predictive indicators directly in your dashboard.</p>
                </div>
            </div>
        </div>
    </main>
    
    <footer class="text-center py-8 text-slate-400 text-xs font-medium bg-[#ecf0f3]">
        <div class="mb-4">
             <img src="tenzofxlogo.png" alt="Tenzo FX" class="h-6 mx-auto opacity-50 grayscale hover:grayscale-0 transition-all">
        </div>
        &copy; <?php echo date('Y'); ?> Tenzo FX. All rights reserved.
    </footer>
</body>
</html>
