<?php
// Tenzo FX - Verify OTP (Light Neumorphic)
require_once 'db.php';
session_start();

$email = $_SESSION['temp_email'] ?? '';
if (!$email) {
    header("Location: register.php");
    exit();
}

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_otp = $_POST['otp'];

    $stmt = $pdo->prepare("SELECT otp_code, otp_expires_at FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && $user['otp_code'] === $user_otp) {
        if (strtotime($user['otp_expires_at']) > time()) {
            
            // Mark verified / set to pending (step 2)
            $stmt = $pdo->prepare("UPDATE users SET status = 'pending', otp_code = NULL WHERE email = ?");
            $stmt->execute([$email]);

            // Auto-login logic could go here, but let's send to pay
            $_SESSION['user_status'] = 'pending'; 
            // We need to get the ID though if we want to set the session for login
             $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
             $stmt->execute([$email]);
             $u = $stmt->fetch();
             $_SESSION['user_id'] = $u['id'];

            header("Location: pay.php");
            exit();
        } else {
            $message = "OTP has expired.";
        }
    } else {
        $message = "Invalid verification code.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Identity - Tenzo FX</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
         body { 
            font-family: 'Outfit', sans-serif; 
            background-color: #ecf0f3; 
            color: #4a5568;
        }
        .neu-card {
            background: #ecf0f3;
            box-shadow: 9px 9px 16px rgb(163,177,198,0.6), 
                       -9px -9px 16px rgba(255,255,255, 0.5);
            border-radius: 20px;
        }
        .neu-inset {
             background: #ecf0f3;
             box-shadow: inset 5px 5px 10px #d1d9e6, 
                        inset -5px -5px 10px #ffffff;
             border-radius: 12px;
        }
        .neu-btn {
            background: #ecf0f3;
            box-shadow: 6px 6px 10px 0 rgba(163,177,198, 0.7), 
                       -6px -6px 10px 0 rgba(255,255,255, 0.8);
            border-radius: 12px;
            transition: all 0.2s ease;
            color: #673ee5;
        }
        .neu-btn:hover {
            transform: translateY(-2px);
            box-shadow: 8px 8px 12px 0 rgba(163,177,198, 0.7), 
                       -8px -8px 12px 0 rgba(255,255,255, 0.8);
        }
        .neu-btn:active {
             transform: translateY(0);
        }
        .text-accent { color: #673ee5; }
    </style>
</head>
<body class="flex items-center justify-center min-h-screen p-4">
    <div class="neu-card w-full max-w-md p-10 text-center">
        <div class="h-20 w-20 neu-inset rounded-full flex items-center justify-center mx-auto mb-8 text-[#673ee5]">
            <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg>
        </div>
        
        <h2 class="text-2xl font-bold text-slate-700 mb-2">Security Check</h2>
        <p class="text-slate-500 text-sm mb-8">Enter the code sent to <br><span class="font-semibold text-slate-600"><?php echo htmlspecialchars($email); ?></span></p>

        <?php if ($message): ?>
             <div class="neu-inset p-4 mb-6 text-center text-red-500 text-sm font-bold">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="space-y-8">
            <div>
                <input type="text" name="otp" required class="neu-inset w-full px-5 py-4 text-center text-2xl tracking-[0.5em] font-bold text-slate-700 outline-none focus:ring-1 focus:ring-[#673ee5]/50 transition-all" maxlength="6" placeholder="000000">
            </div>

            <button type="submit" class="neu-btn w-full py-4 text-sm font-bold uppercase tracking-widest text-[#673ee5]">Verify</button>
        </form>

        <p class="mt-8 text-xs text-slate-400">Code expires in 10 minutes.</p>
    </div>
</body>
</html>
