<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function check_session() {
    // If user is not logged in, redirect to register/login
    // We assume if 'user_id' is set, they are logged in.
    if (!isset($_SESSION['user_id'])) {
        // If we are already on register or login page, do nothing to avoid loop
        $current_script = basename($_SERVER['PHP_SELF']);
        if ($current_script !== 'register.php' && $current_script !== 'login.php' && $current_script !== 'db.php') {
             header("Location: register.php");
             exit();
        }
        return;
    }

    $status = $_SESSION['user_status'] ?? 'unverified';
    $current_script = basename($_SERVER['PHP_SELF']);

    // Logic:
    // unverified -> verify.php
    // pending -> pay.php
    // active -> dashboard.php

    if ($status === 'unverified') {
        if ($current_script !== 'verify.php') {
            header("Location: verify.php");
            exit();
        }
    } elseif ($status === 'pending') {
         if ($current_script !== 'pay.php') {
            header("Location: pay.php");
            exit();
        }
    } elseif ($status === 'active') {
         // Active users should be on dashboard or allowed pages
         // If they try to go to verify or pay, send them to dashboard
         if ($current_script === 'verify.php' || $current_script === 'pay.php' || $current_script === 'register.php') {
             header("Location: dashboard.php");
             exit();
         }
    }
}
?>
