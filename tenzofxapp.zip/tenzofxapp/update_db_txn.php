<?php
require_once 'db.php';

try {
    // Add txn_hash column
    try {
        $pdo->exec("ALTER TABLE users ADD COLUMN txn_hash VARCHAR(255) DEFAULT NULL");
        echo "Added 'txn_hash' column.<br>";
    } catch (PDOException $e) { echo "Column 'txn_hash' likely exists.<br>"; }

    echo "<h3>Database Schema Updated Successfully</h3>";
    echo '<a href="dashboard.php">Return to Dashboard</a>';

} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>
