<?php
// Tenzo FX - Profile Management (Enhanced)
require_once 'db.php';
require_once 'auth_check.php';

check_auth();

$message = '';
$error = '';
$user_id = $_SESSION['user_id'];

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Update Personal Info
    if (isset($_POST['update_profile'])) {
        $first_name = trim($_POST['first_name']);
        $last_name = trim($_POST['last_name']);
        $wallet_id = trim($_POST['wallet_id']);
        
        // Handle Profile Pic (Base64 cropped data)
        $profile_pic_path = null; // No change by default
        if (!empty($_POST['cropped_image'])) {
            $data = $_POST['cropped_image'];
            list($type, $data) = explode(';', $data);
            list(, $data)      = explode(',', $data);
            $data = base64_decode($data);
            
            $filename = 'uploads/profile_' . $user_id . '_' . time() . '.png';
            if (!is_dir('uploads')) mkdir('uploads');
            file_put_contents($filename, $data);
            $profile_pic_path = $filename;
        }

        // Build Query
        $sql = "UPDATE users SET first_name = ?, last_name = ?, wallet_id = ?";
        $params = [$first_name, $last_name, $wallet_id];

        if ($profile_pic_path) {
            $sql .= ", profile_pic = ?";
            $params[] = $profile_pic_path;
        }
        
        $sql .= " WHERE id = ?";
        $params[] = $user_id;

        $stmt = $pdo->prepare($sql);
        if ($stmt->execute($params)) {
             $message = "Profile updated successfully.";
        } else {
             $error = "Failed to update profile.";
        }
    }

    // 2. Update Password
    if (isset($_POST['update_password'])) {
        $current = $_POST['current_password'];
        $new = $_POST['new_password'];
        $confirm = $_POST['confirm_password'];

        if ($new !== $confirm) {
            $error = "New passwords do not match.";
        } else {
            $stmt = $pdo->prepare("SELECT password_hash FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch();

            if ($user && password_verify($current, $user['password_hash'])) {
                $new_hash = password_hash($new, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
                $stmt->execute([$new_hash, $user_id]);
                $message = "Password changed successfully.";
            } else {
                $error = "Incorrect current password.";
            }
        }
    }
}

// Fetch Latest Data
$stmt = $pdo->prepare("SELECT email, first_name, last_name, wallet_id, profile_pic FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

$current_pic = !empty($user['profile_pic']) ? $user['profile_pic'] : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile - Tenzo FX</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.css"/>
    <style>
        body { font-family: 'Outfit', sans-serif; background-color: #ecf0f3; color: #4a5568; }
        .neu-card { background: #ecf0f3; box-shadow: 9px 9px 16px rgb(163,177,198,0.6), -9px -9px 16px rgba(255,255,255, 0.5); border-radius: 20px; }
        .neu-inset { background: #ecf0f3; box-shadow: inset 5px 5px 10px #d1d9e6, inset -5px -5px 10px #ffffff; border-radius: 12px; }
        .neu-btn { background: #ecf0f3; box-shadow: 6px 6px 10px 0 rgba(163,177,198, 0.7), -6px -6px 10px 0 rgba(255,255,255, 0.8); border-radius: 12px; transition: all 0.2s ease; color: #673ee5; }
        .neu-btn:hover { transform: translateY(-2px); box-shadow: 8px 8px 12px 0 rgba(163,177,198, 0.7), -8px -8px 12px 0 rgba(255,255,255, 0.8); }
        .neu-btn:active { transform: translateY(0); box-shadow: inset 4px 4px 8px 0 rgba(163,177,198, 0.7), inset -4px -4px 8px 0 rgba(255,255,255, 0.8); }
    </style>
</head>
<body class="min-h-screen p-6">
    <div class="max-w-4xl mx-auto">
        <a href="dashboard.php" class="inline-flex items-center text-slate-500 hover:text-[#673ee5] mb-8 transition-colors">
            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
            Back to Dashboard
        </a>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <!-- Left: Profile Info -->
            <div class="md:col-span-2 neu-card p-8">
                <h2 class="text-xl font-bold text-slate-700 mb-6">Personal Details</h2>
                
                <?php if ($message): ?> <div class="bg-green-100 text-green-700 p-3 rounded mb-4 text-sm font-bold"><?php echo $message; ?></div> <?php endif; ?>
                <?php if ($error): ?> <div class="bg-red-100 text-red-700 p-3 rounded mb-4 text-sm font-bold"><?php echo $error; ?></div> <?php endif; ?>

                <form method="POST" enctype="multipart/form-data" id="profileForm">
                    <input type="hidden" name="update_profile" value="1">
                    <input type="hidden" name="cropped_image" id="croppedImageInput">

                    <!-- Profile Pic Area -->
                    <div class="flex items-center mb-8 space-x-6">
                        <div class="relative group cursor-pointer">
                            <div class="w-24 h-24 rounded-full neu-inset overflow-hidden flex items-center justify-center bg-slate-100">
                                <?php if ($current_pic): ?>
                                    <img src="<?php echo htmlspecialchars($current_pic); ?>" class="w-full h-full object-cover">
                                <?php else: ?>
                                    <svg class="w-10 h-10 text-slate-300" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd"></path></svg>
                                <?php endif; ?>
                            </div>
                            <div class="absolute inset-0 bg-black/40 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity" onclick="document.getElementById('fileInput').click()">
                                <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                            </div>
                        </div>
                        <div>
                            <button type="button" onclick="document.getElementById('fileInput').click()" class="text-sm font-bold text-[#673ee5] hover:underline">Change Photo</button>
                            <p class="text-xs text-slate-400 mt-1">Click to upload & crop</p>
                        </div>
                        <input type="file" id="fileInput" accept="image/*" class="hidden">
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                        <div>
                            <label class="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">First Name</label>
                            <input type="text" name="first_name" value="<?php echo htmlspecialchars($user['first_name'] ?? ''); ?>" class="w-full neu-inset p-3 bg-transparent text-slate-700 outline-none focus:ring-2 focus:ring-[#673ee5]/20 rounded-lg">
                        </div>
                        <div>
                            <label class="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Last Name</label>
                            <input type="text" name="last_name" value="<?php echo htmlspecialchars($user['last_name'] ?? ''); ?>" class="w-full neu-inset p-3 bg-transparent text-slate-700 outline-none focus:ring-2 focus:ring-[#673ee5]/20 rounded-lg">
                        </div>
                    </div>

                    <div class="mb-6">
                        <label class="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Email Address</label>
                        <input type="email" value="<?php echo htmlspecialchars($user['email']); ?>" disabled class="w-full neu-inset p-3 bg-gray-50/50 text-slate-400 cursor-not-allowed rounded-lg">
                    </div>

                    <div class="mb-8">
                        <label class="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Wallet ID (USDT/BTC)</label>
                        <input type="text" name="wallet_id" value="<?php echo htmlspecialchars($user['wallet_id'] ?? ''); ?>" class="w-full neu-inset p-3 bg-transparent text-slate-700 outline-none focus:ring-2 focus:ring-[#673ee5]/20 rounded-lg font-mono text-sm">
                    </div>

                    <button type="submit" class="neu-btn px-8 py-3 text-sm font-bold uppercase tracking-wider w-full md:w-auto">Save Changes</button>
                </form>
            </div>

            <!-- Right: Security -->
            <div class="neu-card p-8 h-fit">
                <h2 class="text-xl font-bold text-slate-700 mb-6">Security</h2>
                <form method="POST">
                    <input type="hidden" name="update_password" value="1">
                    
                    <div class="mb-4">
                        <label class="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Current Password</label>
                        <input type="password" name="current_password" required class="w-full neu-inset p-3 bg-transparent text-slate-700 outline-none focus:ring-2 focus:ring-[#673ee5]/20 rounded-lg">
                    </div>
                    
                    <div class="mb-4">
                        <label class="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">New Password</label>
                        <input type="password" name="new_password" required class="w-full neu-inset p-3 bg-transparent text-slate-700 outline-none focus:ring-2 focus:ring-[#673ee5]/20 rounded-lg">
                    </div>

                    <div class="mb-6">
                        <label class="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Confirm Password</label>
                        <input type="password" name="confirm_password" required class="w-full neu-inset p-3 bg-transparent text-slate-700 outline-none focus:ring-2 focus:ring-[#673ee5]/20 rounded-lg">
                    </div>

                    <button type="submit" class="neu-btn px-6 py-3 text-sm font-bold uppercase tracking-wider w-full text-red-400 hover:text-red-500">Update Password</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Cropper Modal -->
    <div id="cropperModal" class="fixed inset-0 z-50 bg-black/80 hidden flex items-center justify-center p-4">
        <div class="bg-white rounded-xl overflow-hidden max-w-2xl w-full">
            <div class="p-4 bg-gray-100 flex justify-between items-center">
                <h3 class="font-bold text-gray-700">Crop Image</h3>
                <button onclick="closeCropper()" class="text-gray-500 hover:text-gray-700">&times;</button>
            </div>
            <div class="h-[400px] bg-black">
                <img id="imageToCrop" class="max-w-full h-full block">
            </div>
            <div class="p-4 flex justifying-end space-x-4 bg-gray-50">
                <button onclick="closeCropper()" class="px-4 py-2 text-gray-600 font-bold">Cancel</button>
                <button onclick="saveCrop()" class="px-6 py-2 bg-[#673ee5] text-white rounded font-bold hover:bg-[#5a32d1]">Crop & Update</button>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.js"></script>
    <script>
        let cropper;
        const fileInput = document.getElementById('fileInput');
        const modal = document.getElementById('cropperModal');
        const imageElement = document.getElementById('imageToCrop');

        fileInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(evt) {
                    imageElement.src = evt.target.result;
                    modal.classList.remove('hidden');
                    if(cropper) cropper.destroy();
                    cropper = new Cropper(imageElement, {
                        aspectRatio: 1,
                        viewMode: 1
                    });
                };
                reader.readAsDataURL(file);
            }
        });

        function closeCropper() {
            modal.classList.add('hidden');
            fileInput.value = '';
            if(cropper) cropper.destroy();
        }

        function saveCrop() {
            if(cropper) {
                // Get cropped canvas
                const canvas = cropper.getCroppedCanvas({
                    width: 300,
                    height: 300
                });
                // Convert to Base64
                const base64Image = canvas.toDataURL('image/png');
                
                // Put into hidden input and submit form
                document.getElementById('croppedImageInput').value = base64Image;
                document.getElementById('profileForm').submit();
            }
        }
    </script>
</body>
</html>
