<?php
// Tenzo FX - Login (Light Neumorphic)
require_once 'db.php';
session_start();

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT id, password_hash, status FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password_hash'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_status'] = $user['status'];
        header("Location: dashboard.php");
        exit();
    } else {
        $message = "Invalid credentials.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Tenzo FX</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
         body { 
            font-family: 'Outfit', sans-serif; 
            background-color: #ecf0f3; 
            color: #4a5568;
        }
        .neu-card {
            background: #ecf0f3;
            box-shadow: 9px 9px 16px rgb(163,177,198,0.6), 
                       -9px -9px 16px rgba(255,255,255, 0.5);
            border-radius: 20px;
        }
        .neu-inset {
             background: #ecf0f3;
             box-shadow: inset 5px 5px 10px #d1d9e6, 
                        inset -5px -5px 10px #ffffff;
             border-radius: 12px;
        }
        .neu-btn {
            background: #ecf0f3;
            box-shadow: 6px 6px 10px 0 rgba(163,177,198, 0.7), 
                       -6px -6px 10px 0 rgba(255,255,255, 0.8);
            border-radius: 12px;
            transition: all 0.2s ease;
            color: #673ee5;
        }
        .neu-btn:hover {
            transform: translateY(-2px);
            box-shadow: 8px 8px 12px 0 rgba(163,177,198, 0.7), 
                       -8px -8px 12px 0 rgba(255,255,255, 0.8);
        }
        .neu-btn:active {
             transform: translateY(0);
        }
        .text-accent { color: #673ee5; }
    </style>
</head>
<body class="flex items-center justify-center min-h-screen p-4">
    <div class="neu-card w-full max-w-md p-10">
        <div class="text-center mb-10">
            <img src="tenzofxlogo.png" alt="Tenzo FX" class="h-16 mx-auto mb-6 drop-shadow-md">
            <h2 class="text-2xl font-bold text-slate-700">Welcome Back</h2>
            <p class="text-slate-500 text-sm mt-2">Sign in to your dashboard</p>
        </div>

        <?php if ($message): ?>
             <div class="neu-inset p-4 mb-6 text-center text-red-500 text-sm font-bold">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="space-y-6">
            <div>
                <label class="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 pl-2">Email Address</label>
                <input type="email" name="email" required class="neu-inset w-full px-5 py-4 text-slate-700 outline-none focus:ring-1 focus:ring-[#673ee5]/50 transition-all font-medium" placeholder="you@example.com">
            </div>
            
            <div>
                <label class="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 pl-2">Password</label>
                <input type="password" name="password" required class="neu-inset w-full px-5 py-4 text-slate-700 outline-none focus:ring-1 focus:ring-[#673ee5]/50 transition-all font-medium" placeholder="••••••••">
            </div>

            <div class="pt-4">
                <button type="submit" class="neu-btn w-full py-4 text-sm font-bold uppercase tracking-widest text-[#673ee5]">Access Account</button>
            </div>
        </form>

        <div class="mt-8 text-center text-sm">
            <span class="text-slate-400">New here?</span> <a href="register.php" class="text-[#673ee5] font-bold hover:underline ml-1">Create Account</a>
        </div>
    </div>
</body>
</html>
