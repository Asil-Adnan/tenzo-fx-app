<?php
// Tenzo FX - Dashboard (Restored & Polished)
require_once 'db.php';
require_once 'auth_check.php';

check_auth();

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit();
}

// Data Fetch
$stmt = $pdo->prepare("SELECT status, investment, profit_percentage, email, first_name, last_name, profile_pic, txn_hash FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user_db = $stmt->fetch();

$status = $user_db['status'] ?? 'unverified';
$_SESSION['user_status'] = $status;

$investment = floatval($user_db['investment'] ?? 0);
$profit_pct = floatval($user_db['profit_percentage'] ?? 0);
$profit_amount = $investment * ($profit_pct / 100);
$total_balance = $investment + $profit_amount;

$fName = $user_db['first_name'] ?? '';
$lName = $user_db['last_name'] ?? '';
$displayName = ($fName || $lName) ? trim(htmlspecialchars("$fName $lName")) : 'New User';

$msg_deposit = '';
$msg_pending = '';

// Form Handlers
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['submit_proof'])) {
        $hash = trim($_POST['txn_hash']);
        $amt = floatval($_POST['investment_amount']);
        if ($hash) {
            $pdo->prepare("UPDATE users SET txn_hash = ?, investment = ? WHERE id = ?")->execute([$hash, $amt, $_SESSION['user_id']]);
            $msg_pending = "Proof submitted.";
            $user_db['txn_hash'] = $hash;
        }
    }
    if (isset($_POST['submit_deposit'])) {
        $hash = trim($_POST['txn_hash']);
        $amt = floatval($_POST['investment_amount']);
        if ($hash && $amt > 0) {
            $pdo->prepare("INSERT INTO deposits (user_id, amount, txn_hash) VALUES (?, ?, ?)")->execute([$_SESSION['user_id'], $amt, $hash]);
            header("Location: dashboard.php?deposit_success=1");
            exit();
        }
    }
}

if (isset($_GET['deposit_success'])) $msg_deposit = "Deposit Pending: Request submitted.";

// View Router
$view_mode = 'dashboard';
if ($status !== 'active') $view_mode = 'pending';
if (isset($_GET['action']) && $_GET['action'] == 'submit_deposit') $view_mode = 'deposit';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tenzo FX</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Outfit', sans-serif; background-color: #ecf0f3; color: #4a5568; }
        .neu-card { background: #ecf0f3; box-shadow: 9px 9px 16px rgb(163,177,198,0.6), -9px -9px 16px rgba(255,255,255, 0.5); border-radius: 20px; }
        .neu-inset { background: #ecf0f3; box-shadow: inset 5px 5px 10px #d1d9e6, inset -5px -5px 10px #ffffff; border-radius: 12px; }
        .neu-btn { background: #ecf0f3; box-shadow: 6px 6px 10px 0 rgba(163,177,198, 0.7), -6px -6px 10px 0 rgba(255,255,255, 0.8); border-radius: 12px; transition: all 0.2s ease; }
        .neu-btn:hover { transform: translateY(-2px); box-shadow: 8px 8px 12px 0 rgba(163,177,198, 0.7), -8px -8px 12px 0 rgba(255,255,255, 0.8); }
        .neu-btn:active { transform: translateY(0); box-shadow: inset 4px 4px 8px 0 rgba(163,177,198, 0.7), inset -4px -4px 8px 0 rgba(255,255,255, 0.8); }
    </style>
</head>
<body class="bg-[#ecf0f3]">

<?php if ($view_mode === 'pending'): ?>
    <div class="flex items-center justify-center min-h-screen p-4">
        <div class="neu-card w-full max-w-lg p-10 text-center relative">
            <h2 class="text-2xl font-bold text-slate-700 mb-2">Account Activation</h2>
            <p class="text-slate-500 mb-8 text-sm">Please verify your payment.</p>
            <?php if (!empty($user_db['txn_hash']) || $msg_pending): ?>
                <div class="mb-6 p-4 bg-green-100 text-green-700 rounded-xl text-sm font-bold">Proof submitted.</div>
                <a href="?logout=1" class="neu-btn px-6 py-3 text-xs font-bold text-red-500 uppercase">Log Out</a>
            <?php else: ?>
                <form method="POST" class="text-left">
                    <input type="number" name="investment_amount" placeholder="Amount ($)" class="neu-inset w-full px-4 py-3 mb-4 font-bold focus:outline-none" required>
                    <textarea name="txn_hash" rows="2" placeholder="Transaction Hash" class="neu-inset w-full px-4 py-3 mb-6 font-mono text-sm focus:outline-none" required></textarea>
                    <button type="submit" name="submit_proof" class="neu-btn w-full py-4 text-[#673ee5] font-bold uppercase">Submit Proof</button>
                    <a href="pay.php" class="block text-center mt-4 text-xs font-bold text-slate-400 uppercase">Back to Payment</a>
                </form>
            <?php endif; ?>
        </div>
    </div>

<?php elseif ($view_mode === 'deposit'): ?>
    <div class="flex items-center justify-center min-h-screen p-4">
        <div class="neu-card w-full max-w-lg p-10 text-center relative">
            <h2 class="text-2xl font-bold text-slate-700 mb-2">Add Deposit</h2>
            <form method="POST" class="text-left mt-8">
                <input type="number" name="investment_amount" placeholder="Amount ($)" class="neu-inset w-full px-4 py-3 mb-4 font-bold focus:outline-none" required>
                <textarea name="txn_hash" rows="2" placeholder="Transaction Hash" class="neu-inset w-full px-4 py-3 mb-6 font-mono text-sm focus:outline-none" required></textarea>
                <button type="submit" name="submit_deposit" class="neu-btn w-full py-4 text-[#673ee5] font-bold uppercase">Confirm Deposit</button>
                <a href="dashboard.php" class="block text-center mt-4 text-xs font-bold text-slate-400 uppercase">Cancel</a>
            </form>
        </div>
    </div>

<?php else: ?>
    <!-- ACTIVE DASHBOARD -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        <!-- Header -->
        <div class="flex justify-between items-center mb-10">
            <img src="tenzofxlogo.png" alt="Tenzo FX" class="h-8 w-auto">
            <div class="flex items-center space-x-4">
                <div class="neu-btn px-4 py-2 flex items-center space-x-2 rounded-xl">
                    <span class="relative flex h-2 w-2">
                      <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                      <span class="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                    </span>
                    <span class="text-[10px] font-bold text-slate-500 uppercase tracking-wide">LIVE</span>
                </div>
                <a href="?logout=1" class="neu-btn px-6 py-2 text-xs font-bold uppercase tracking-wider text-red-400 hover:text-red-500 rounded-xl">LOG OUT</a>
            </div>
        </div>

        <?php if ($msg_deposit): ?>
        <div class="mb-8 p-4 bg-yellow-100 border border-yellow-200 text-yellow-700 rounded-xl text-sm font-bold shadow-sm"><?php echo $msg_deposit; ?></div>
        <?php endif; ?>

        <!-- Welcome -->
        <div class="neu-card p-10 mb-8 flex flex-col md:flex-row items-center justify-between">
            <div>
                <h1 class="text-4xl font-extrabold mb-2 tracking-tight text-[#673ee5]">Welcome Back <?php echo $displayName; ?></h1>
                <p class="text-slate-500 font-bold"><?php echo htmlspecialchars($user_db['email']); ?></p>
            </div>
            <a href="profile.php" class="block mt-4 md:mt-0 h-16 w-16 rounded-full neu-inset border-2 border-white overflow-hidden hover:opacity-80 transition">
                <?php if(!empty($user_db['profile_pic'])): ?>
                    <img src="<?php echo htmlspecialchars($user_db['profile_pic']); ?>" class="h-full w-full object-cover">
                <?php else: ?>
                    <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($displayName); ?>&background=random" class="h-full w-full object-cover">
                <?php endif; ?>
            </a>
        </div>

        <!-- Stats -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div class="neu-card p-8 flex flex-col justify-between h-56">
                <div>
                    <p class="text-slate-400 text-[10px] font-bold uppercase tracking-widest mb-4">Investment Capital</p>
                    <div class="text-3xl font-bold text-slate-700 font-mono tracking-tight">$<?php echo number_format($investment, 2); ?></div>
                </div>
                <a href="pay.php" class="neu-btn w-full py-3 text-center text-xs font-bold uppercase tracking-wider text-[#673ee5]">DEPOSIT</a>
            </div>
            <div class="neu-card p-8 flex flex-col justify-between h-56">
                <div>
                    <p class="text-slate-400 text-[10px] font-bold uppercase tracking-widest mb-4">Profit Margin</p>
                    <div class="text-3xl font-bold text-slate-700 font-mono tracking-tight"><?php echo number_format($profit_pct, 2); ?>%</div>
                    <div class="mt-4 text-xs text-green-500 font-bold flex items-center">
                        <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path></svg>
                        Performing Well
                    </div>
                </div>
            </div>
            <div class="neu-card p-8 flex flex-col justify-between h-56 border-l-4 border-[#673ee5]">
                <div>
                    <p class="text-slate-400 text-[10px] font-bold uppercase tracking-widest mb-4">Total Balance</p>
                    <div class="text-4xl font-bold text-[#673ee5] font-mono tracking-tight mb-2">$<?php echo number_format($total_balance, 2); ?></div>
                    <span class="bg-green-100 text-green-600 px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wide">+<?php echo number_format($profit_pct, 1); ?>% profit</span>
                </div>
                <button class="neu-btn w-full py-3 text-center text-xs font-bold uppercase tracking-wider text-[#673ee5]">WITHDRAW</button>
            </div>
        </div>

        <!-- Chart & News -->
        <div class="grid grid-cols-1 md:grid-cols-12 gap-6">
            <div class="md:col-span-8">
                 <h3 class="font-bold text-slate-700 mb-4 ml-1">XAU/USD (Gold) - Live Market</h3>
                 
                 <div class="neu-card p-1 rounded-2xl overflow-hidden shadow-inner h-[500px] relative">
                    <!-- BLOCK INTERACTIONS -->
                    <div class="absolute inset-0 z-50"></div>
                    
                    <div class="tradingview-widget-container" style="height:100%;width:100%">
                      <div class="tradingview-widget-container__widget" style="height:100%;width:100%"></div>
                      <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-mini-symbol-overview.js" async>
                      {
                      "symbol": "OANDA:XAUUSD",
                      "width": "100%",
                      "height": "100%",
                      "locale": "en",
                      "dateRange": "12M",
                      "colorTheme": "light",
                      "trendLineColor": "#673ee5",
                      "underLineColor": "rgba(103, 62, 229, 0.3)",
                      "isTransparent": true,
                      "autosize": true,
                      "largeChartUrl": ""
                    }
                      </script>
                    </div>
                 </div>
            </div>

            <div class="md:col-span-4 neu-card p-6 h-[540px] overflow-y-auto">
                 <h3 class="font-bold text-slate-700 mb-6">Market News</h3>
                 <!-- Static News Items -->
                 <div class="space-y-6">
                     <div class="pb-4 border-b border-gray-200/50">
                         <span class="text-[10px] font-bold text-[#673ee5] uppercase">10 mins ago</span>
                         <p class="text-sm text-slate-600 font-medium mt-1">US dollar steady ahead of key inflation data.</p>
                     </div>
                     <div class="pb-4 border-b border-gray-200/50">
                         <span class="text-[10px] font-bold text-[#673ee5] uppercase">25 mins ago</span>
                         <p class="text-sm text-slate-600 font-medium mt-1">Gold prices fluctuate near record highs as investors seek safe havens.</p>
                     </div>
                      <div class="pb-4 border-b border-gray-200/50">
                         <span class="text-[10px] font-bold text-[#673ee5] uppercase">1 hour ago</span>
                         <p class="text-sm text-slate-600 font-medium mt-1">Tech stocks rally continues into late trading session.</p>
                     </div>
                     <div>
                         <span class="text-[10px] font-bold text-[#673ee5] uppercase">2 hours ago</span>
                         <p class="text-sm text-slate-600 font-medium mt-1">Oil prices dip slightly on demand concerns.</p>
                     </div>
                 </div>
            </div>
        </div>
    </div>
<?php endif; ?>
</body>
</html>
