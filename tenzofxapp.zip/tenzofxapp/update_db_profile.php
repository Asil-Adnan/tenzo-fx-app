<?php
require_once 'db.php';

try {
    // Add first_name column
    try {
        $pdo->exec("ALTER TABLE users ADD COLUMN first_name VARCHAR(100) DEFAULT NULL");
        echo "Added 'first_name' column.<br>";
    } catch (PDOException $e) { echo "Column 'first_name' likely exists.<br>"; }

    // Add last_name column
    try {
        $pdo->exec("ALTER TABLE users ADD COLUMN last_name VARCHAR(100) DEFAULT NULL");
        echo "Added 'last_name' column.<br>";
    } catch (PDOException $e) { echo "Column 'last_name' likely exists.<br>"; }

    // Add profile_pic column
    try {
        $pdo->exec("ALTER TABLE users ADD COLUMN profile_pic VARCHAR(255) DEFAULT NULL");
        echo "Added 'profile_pic' column.<br>";
    } catch (PDOException $e) { echo "Column 'profile_pic' likely exists.<br>"; }

    // Add wallet_id column
    try {
        $pdo->exec("ALTER TABLE users ADD COLUMN wallet_id VARCHAR(255) DEFAULT NULL");
        echo "Added 'wallet_id' column.<br>";
    } catch (PDOException $e) { echo "Column 'wallet_id' likely exists.<br>"; }

    echo "<h3>Database Schema Updated Successfully</h3>";
    echo '<a href="dashboard.php">Return to Dashboard</a>';

} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>
