<?php
// Tenzo FX - Unified Authentication & Redirection Engine
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function check_auth() {
    $current_script = basename($_SERVER['PHP_SELF']);
    $public_pages = ['login.php', 'register.php', 'db.php', 'index.php']; // index.php might be public

    // 1. Check Login
    if (!isset($_SESSION['user_id'])) {
        if (!in_array($current_script, $public_pages)) {
            header("Location: login.php");
            exit();
        }
        return; // Allow public pages
    }

    // 2. Check Status & Enforce Flow
    $status = $_SESSION['user_status'] ?? 'unverified';

    // Status: UNVERIFIED
    if ($status === 'unverified') {
        if ($current_script !== 'verify.php') {
            header("Location: verify.php");
            exit();
        }
    }
    // Status: PENDING
    elseif ($status === 'pending') {
        // Pending users can visit pay.php OR dashboard.php (where they see a restricted view)
        if ($current_script !== 'pay.php' && $current_script !== 'dashboard.php') {
            header("Location: dashboard.php"); // Redirect to dashboard, which will show the "Make Payment" prompt
            exit();
        }
    }
    // Status: ACTIVE
    elseif ($status === 'active') {
        // Active users shouldn't be on verify or register/login
        // ALLOW pay.php for deposits
        if ($current_script === 'verify.php' || $current_script === 'register.php' || $current_script === 'login.php') {
            header("Location: dashboard.php");
            exit();
        }
    }
}
?>
