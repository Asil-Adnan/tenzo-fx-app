<?php
require_once 'db.php';

try {
    echo "Attempting to update database schema...\n";

    // Add investment column if it doesn't exist
    $sql1 = "ALTER TABLE users ADD COLUMN investment DECIMAL(15,2) DEFAULT 0.00";
    try {
        $pdo->exec($sql1);
        echo "Success: Added 'investment' column.\n";
    } catch (PDOException $e) {
        // Ignore if exists (error code 42S21 in MySQL for duplicate column, but PDO might throw generic)
        echo "Note: 'investment' column might already exist or error: " . $e->getMessage() . "\n";
    }

    // Add profit_percentage column if it doesn't exist
    $sql2 = "ALTER TABLE users ADD COLUMN profit_percentage DECIMAL(5,2) DEFAULT 0.00";
    try {
        $pdo->exec($sql2);
        echo "Success: Added 'profit_percentage' column.\n";
    } catch (PDOException $e) {
         echo "Note: 'profit_percentage' column might already exist or error: " . $e->getMessage() . "\n";
    }
    
    echo "Database update process finished.\n";

} catch (Exception $e) {
    echo "CRITICAL ERROR: " . $e->getMessage() . "\n";
}
?>
