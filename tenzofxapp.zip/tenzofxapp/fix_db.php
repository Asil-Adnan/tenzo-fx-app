<?php
require_once 'db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Database Repair - Tenzo FX</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <div class="bg-white p-8 rounded-lg shadow-lg max-w-md w-full">
        <h1 class="text-xl font-bold mb-4">Database Schema Update</h1>
        <div class="space-y-4">
<?php
try {
    // Add investment column
    $sql1 = "ALTER TABLE users ADD COLUMN investment DECIMAL(15,2) DEFAULT 0.00";
    try {
        $pdo->exec($sql1);
        echo '<div class="p-3 bg-green-50 text-green-700 rounded border border-green-200">✅ Added "investment" column</div>';
    } catch (PDOException $e) {
        if (strpos($e->getMessage(), 'Duplicate column') !== false || $e->getCode() == '42S21') {
             echo '<div class="p-3 bg-yellow-50 text-yellow-700 rounded border border-yellow-200">ℹ️ "investment" column already exists</div>';
        } else {
             echo '<div class="p-3 bg-red-50 text-red-700 rounded border border-red-200">❌ Error investment: ' . $e->getMessage() . '</div>';
        }
    }

    // Add profit_percentage column
    $sql2 = "ALTER TABLE users ADD COLUMN profit_percentage DECIMAL(5,2) DEFAULT 0.00";
    try {
        $pdo->exec($sql2);
        echo '<div class="p-3 bg-green-50 text-green-700 rounded border border-green-200">✅ Added "profit_percentage" column</div>';
    } catch (PDOException $e) {
         if (strpos($e->getMessage(), 'Duplicate column') !== false|| $e->getCode() == '42S21') {
             echo '<div class="p-3 bg-yellow-50 text-yellow-700 rounded border border-yellow-200">ℹ️ "profit_percentage" column already exists</div>';
        } else {
             echo '<div class="p-3 bg-red-50 text-red-700 rounded border border-red-200">❌ Error profit_pct: ' . $e->getMessage() . '</div>';
        }
    }

    echo '<div class="mt-4 pt-4 border-t border-gray-100 font-bold text-center text-slate-700">Database is ready.</div>';
    echo '<a href="dashboard.php" class="block mt-4 bg-indigo-600 text-white text-center py-2 rounded hover:bg-indigo-700">Return to Dashboard</a>';

} catch (Exception $e) {
    echo '<div class="p-4 bg-red-100 text-red-800 rounded">CRITICAL ERROR: ' . $e->getMessage() . '</div>';
}
?>
        </div>
    </div>
</body>
</html>
