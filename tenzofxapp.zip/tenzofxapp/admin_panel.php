<?php
// Tenzo FX - Admin Panel (Screenshot Design Match)
require_once 'db.php';
session_start();

$admin_pass_hash = password_hash('admin123', PASSWORD_DEFAULT); 
$message = '';
$current_page = $_GET['page'] ?? 'new_users';

// --- Auth Logic ---
if (isset($_POST['login'])) {
    if (password_verify($_POST['password'], $admin_pass_hash) || $_POST['password'] === 'admin123') {
        $_SESSION['is_admin'] = true;
    } else {
        $message = "Invalid access key.";
    }
}

if (isset($_GET['logout'])) {
    unset($_SESSION['is_admin']);
    header("Location: admin_panel.php");
    exit();
}

// --- Action Logic ---
if (isset($_POST['approve_user']) && isset($_SESSION['is_admin'])) {
    $user_id = $_POST['user_id'];
    $investment = $_POST['investment'] ?? 0;
    
    // Fetch global profit
    $stmt = $pdo->query("SELECT profit_percentage FROM users WHERE status = 'active' LIMIT 1");
    $global_profit = $stmt->fetchColumn() ?: 0;

    $stmt = $pdo->prepare("UPDATE users SET status = 'active', investment = ?, profit_percentage = ? WHERE id = ?");
    if ($stmt->execute([$investment, $global_profit, $user_id])) {
        $message = "User #$user_id activated.";
    }
}

if (isset($_POST['update_financials']) && isset($_SESSION['is_admin'])) {
    $user_id = $_POST['user_id'];
    $investment = $_POST['investment'];
    $profit_percentage = $_POST['profit_percentage'];
    $stmt = $pdo->prepare("UPDATE users SET investment = ?, profit_percentage = ? WHERE id = ?");
    $stmt->execute([$investment, $profit_percentage, $user_id]);
    $message = "Updated User #$user_id.";
}

if (isset($_POST['update_global_profit']) && isset($_SESSION['is_admin'])) {
    $global_profit = $_POST['global_profit_percentage'];
    $stmt = $pdo->prepare("UPDATE users SET profit_percentage = ? WHERE status = 'active'");
    $stmt->execute([$global_profit]);
    $message = "Global profit set to $global_profit%.";
}

if (isset($_POST['approve_deposit']) && isset($_SESSION['is_admin'])) {
    $deposit_id = $_POST['deposit_id'];
    $stmt = $pdo->prepare("SELECT * FROM deposits WHERE id = ?");
    $stmt->execute([$deposit_id]);
    $deposit = $stmt->fetch();
    if ($deposit && $deposit['status'] === 'pending') {
        $pdo->prepare("UPDATE users SET investment = investment + ? WHERE id = ?")->execute([$deposit['amount'], $deposit['user_id']]);
        $pdo->prepare("UPDATE deposits SET status = 'approved' WHERE id = ?")->execute([$deposit_id]);
        $message = "Deposit approved.";
    }
}

if (isset($_POST['reject_deposit']) && isset($_SESSION['is_admin'])) {
    $deposit_id = $_POST['deposit_id'];
    $pdo->prepare("UPDATE deposits SET status = 'rejected' WHERE id = ?")->execute([$deposit_id]);
    $message = "Deposit rejected.";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Tenzo FX</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Outfit', sans-serif; background-color: #ecf0f3; color: #4a5568; }
        
        /* Neumorphic Utilities */
        .neu-card { 
            background: #ecf0f3; 
            box-shadow: 9px 9px 16px rgb(163,177,198,0.6), 
                       -9px -9px 16px rgba(255,255,255, 0.5); 
            border-radius: 20px; 
        }
        .neu-card-flat {
            background: #ecf0f3;
            box-shadow: 6px 6px 12px #b8b9be, -6px -6px 12px #ffffff;
            border-radius: 16px;
        }
        .neu-inset { 
            background: #ecf0f3; 
            box-shadow: inset 5px 5px 10px #d1d9e6, 
                       inset -5px -5px 10px #ffffff; 
            border-radius: 12px; 
        }
        .neu-btn { 
            background: #ecf0f3; 
            box-shadow: 6px 6px 10px 0 rgba(163,177,198, 0.7), 
                       -6px -6px 10px 0 rgba(255,255,255, 0.8); 
            border-radius: 12px; 
            transition: all 0.2s ease; 
        }
        .neu-btn:hover { 
            transform: translateY(-2px); 
            box-shadow: 8px 8px 12px 0 rgba(163,177,198, 0.7), 
                       -8px -8px 12px 0 rgba(255,255,255, 0.8); 
        }
        .neu-btn:active {
            transform: translateY(0);
            box-shadow: inset 4px 4px 8px 0 rgba(163,177,198, 0.7), 
                       inset -4px -4px 8px 0 rgba(255,255,255, 0.8);
        }
        
        .neu-sidebar-btn {
            display: flex;
            align-items: center;
            padding: 16px 24px;
            margin-bottom: 16px;
            border-radius: 12px;
            font-weight: 600;
            color: #64748b;
            transition: all 0.2s;
        }
        .neu-sidebar-btn.active {
            background: #ecf0f3;
            box-shadow: inset 5px 5px 10px #d1d9e6, inset -5px -5px 10px #ffffff;
            color: #673ee5;
        }
        .neu-sidebar-btn:not(.active):hover {
            color: #673ee5;
            background: rgba(255,255,255,0.5);
        }

        /* Specific Table Styling */
        .table-row-card {
            background: #ecf0f3;
            border-radius: 12px;
            margin-bottom: 12px;
        }
    </style>
</head>
<body class="bg-[#ecf0f3] min-h-screen">

<!-- LOGIN -->
<?php if (!isset($_SESSION['is_admin'])): ?>
<div class="flex items-center justify-center min-h-screen p-4">
    <div class="neu-card p-10 w-full max-w-md text-center">
        <h2 class="text-2xl font-bold text-slate-700 mb-6">Admin Login</h2>
        <form method="POST">
            <input type="password" name="password" placeholder="Key" class="neu-inset w-full px-4 py-3 mb-6 focus:outline-none font-bold text-slate-700">
            <button type="submit" name="login" class="neu-btn w-full py-3 text-[#673ee5] font-bold uppercase tracking-wider">Enter</button>
        </form>
    </div>
</div>
<?php exit(); endif; ?>

<!-- LAYOUT -->
<div class="flex min-h-screen">
    
    <!-- SIDEBAR -->
    <aside class="w-72 fixed h-full bg-[#ecf0f3] border-r border-slate-200/50 hidden lg:block z-20">
        <div class="p-8">
            <div class="flex items-center space-x-2 mb-12">
                <img src="tenzofxlogo.png" alt="Logo" class="h-8">
                <span class="text-2xl font-bold text-[#673ee5]">Tenzo FX</span>
            </div>
            
            <nav>
                <a href="?page=new_users" class="neu-sidebar-btn <?php echo $current_page == 'new_users' ? 'active' : ''; ?>">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"></path></svg>
                    New User Approval
                </a>
                <a href="?page=active_traders" class="neu-sidebar-btn <?php echo $current_page == 'active_traders' ? 'active' : ''; ?>">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
                    User Management
                </a>
                <a href="?page=deposits" class="neu-sidebar-btn <?php echo $current_page == 'deposits' ? 'active' : ''; ?>">
                    <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    Deposit Verification
                </a>
            </nav>

            <a href="?logout=1" class="neu-btn block text-center py-3 mt-20 text-xs font-bold text-red-400 hover:text-red-500 tracking-wider">LOG OUT</a>
        </div>
    </aside>

    <!-- CONTENT -->
    <main class="flex-1 lg:ml-72 p-8 lg:p-12">
        
        <!-- HEADER -->
        <div class="flex justify-between items-start mb-10">
            <div>
                <?php if($current_page == 'new_users'): ?>
                    <h1 class="text-3xl font-bold text-slate-800">Pending Approvals</h1>
                    <p class="text-slate-500 font-medium mt-1">Authorize new user accounts</p>
                <?php elseif($current_page == 'active_traders'): ?>
                    <h1 class="text-3xl font-bold text-slate-800">User Financials</h1>
                    <p class="text-slate-500 font-medium mt-1">Manage investment and profit settings</p>
                <?php elseif($current_page == 'deposits'): ?>
                    <h1 class="text-3xl font-bold text-slate-800">Deposit Verification</h1>
                    <p class="text-slate-500 font-medium mt-1">Verify and approve fund deposits</p>
                <?php endif; ?>
            </div>
            
            <div class="neu-btn h-10 w-10 flex items-center justify-center rounded-full text-[#673ee5] font-bold text-sm">
                A
            </div>
        </div>

        <?php if($message): ?>
            <div class="mb-8 font-bold text-green-600 bg-green-100 p-4 rounded-xl text-sm shadow-sm"><?php echo $message; ?></div>
        <?php endif; ?>

        <!-- PAGE 1: NEW USER APPROVAL -->
        <?php if($current_page == 'new_users'): ?>
            <div class="neu-card p-6">
                <!-- Table Header -->
                <div class="grid grid-cols-12 gap-4 mb-4 px-4 text-xs font-bold text-slate-400 uppercase tracking-wider">
                    <div class="col-span-1">User ID</div>
                    <div class="col-span-3">Identity</div>
                    <div class="col-span-2">Date</div>
                    <div class="col-span-2">Status</div>
                    <div class="col-span-2">Income</div>
                    <div class="col-span-2 text-right">Action</div>
                </div>

                <div class="space-y-4">
                    <?php 
                    $pending = $pdo->query("SELECT * FROM users WHERE status = 'pending' ORDER BY created_at DESC");
                    while ($row = $pending->fetch()): 
                    ?>
                    <div class="p-4 border-b border-slate-200/50 hover:bg-white/40 transition rounded-xl">
                        <!-- Top Row: Main Info -->
                        <div class="grid grid-cols-12 gap-4 items-center">
                            <div class="col-span-1 text-sm font-bold text-[#673ee5]">#<?php echo $row['id']; ?></div>
                            <div class="col-span-3">
                                <div class="font-bold text-slate-700 text-sm"><?php echo htmlspecialchars($row['email']); ?></div>
                            </div>
                            <div class="col-span-2 text-xs text-slate-500"><?php echo date('M d, H:i', strtotime($row['created_at'])); ?></div>
                            <div class="col-span-2">
                                <span class="h-2 w-8 bg-yellow-300 rounded-full block"></span>
                            </div>
                            <div class="col-span-2">
                                <span class="font-mono font-bold text-slate-700">$<?php echo number_format($row['investment'], 2); ?></span>
                            </div>
                            <div class="col-span-2 text-right">
                                <form method="POST">
                                    <input type="hidden" name="user_id" value="<?php echo $row['id']; ?>">
                                    <input type="hidden" name="investment" value="<?php echo $row['investment']; ?>">
                                    <button type="submit" name="approve_user" class="neu-btn px-6 py-2 text-xs font-bold text-[#673ee5] uppercase tracking-wider hover:bg-[#673ee5] hover:text-white">Activate</button>
                                </form>
                            </div>
                        </div>
                        
                        <!-- Bottom Row: Hash ID -->
                        <div class="mt-3">
                             <div class="text-[10px] font-bold text-slate-400 uppercase mb-1">Hash ID</div>
                             <div class="w-full neu-inset p-3 rounded-lg overflow-x-auto">
                                 <div class="font-mono text-xs text-slate-600 whitespace-nowrap">
                                     <?php echo !empty($row['txn_hash']) ? htmlspecialchars($row['txn_hash']) : 'N/A'; ?>
                                 </div>
                             </div>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </div>
            </div>

        <!-- PAGE 2: USER MANAGEMENT (Active Traders) -->
        <?php elseif($current_page == 'active_traders'): ?>
            
            <!-- Global Control Bar -->
            <div class="neu-card p-4 mb-8 flex flex-col md:flex-row items-center justify-between">
                <div class="flex items-center mb-4 md:mb-0">
                    <div class="h-10 w-10 neu-inset rounded-full flex items-center justify-center text-[#673ee5] mr-4">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
                    </div>
                    <div>
                        <div class="font-bold text-slate-800 text-sm">Global Control</div>
                        <div class="text-[10px] text-slate-400 uppercase tracking-wide">Set Profit % for All</div>
                    </div>
                </div>
                
                <form method="POST" class="flex items-center space-x-4 w-full md:w-auto">
                    <div class="flex items-center">
                        <span class="text-xs font-bold text-[#673ee5] mr-2 uppercase">Set All Profit %:</span>
                        <?php 
                        $stmt = $pdo->query("SELECT profit_percentage FROM users WHERE status = 'active' LIMIT 1");
                        $current_global_profit = $stmt->fetchColumn() ?: '';
                        ?>
                        <input type="number" step="0.01" name="global_profit_percentage" value="<?php echo htmlspecialchars($current_global_profit); ?>" class="neu-inset w-24 px-3 py-2 text-slate-700 font-bold focus:outline-none rounded-lg text-sm bg-white" placeholder="2.45">
                    </div>
                    <button type="submit" name="update_global_profit" class="neu-btn px-6 py-3 bg-[#673ee5] text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-lg hover:bg-[#5b35d6]">Apply to All</button>
                </form>
            </div>

            <!-- User Rows -->
            <div class="space-y-6">
                <?php 
                $active = $pdo->query("SELECT * FROM users WHERE status = 'active' ORDER BY investment DESC");
                while ($row = $active->fetch()): 
                ?>
                <div class="neu-card p-4 flex flex-col md:flex-row items-center justify-between">
                    <!-- User Info -->
                    <div class="flex items-center w-full md:w-1/4 mb-4 md:mb-0">
                        <div class="h-10 w-10 neu-inset rounded-full flex items-center justify-center text-slate-400 font-bold mr-4 text-sm">
                            <?php echo strtoupper(substr($row['email'], 0, 1)); ?>
                        </div>
                        <div>
                            <div class="font-bold text-slate-700 text-sm">User #<?php echo $row['id']; ?></div>
                            <div class="text-xs text-slate-400"><?php echo htmlspecialchars($row['email']); ?></div>
                        </div>
                    </div>

                    <!-- Controls -->
                    <form method="POST" class="flex flex-col md:flex-row items-center w-full md:w-3/4 justify-end space-y-4 md:space-y-0 md:space-x-6">
                        <input type="hidden" name="user_id" value="<?php echo $row['id']; ?>">
                        
                        <div class="w-full md:w-auto">
                            <label class="block text-[10px] font-bold text-slate-400 uppercase mb-1 ml-1">Investment ($)</label>
                            <input type="number" step="0.01" name="investment" value="<?php echo $row['investment']; ?>" class="neu-inset w-full md:w-40 px-4 py-2 text-slate-700 font-bold focus:outline-none rounded-lg text-sm bg-white/50">
                        </div>

                        <div class="w-full md:w-auto">
                            <label class="block text-[10px] font-bold text-slate-400 uppercase mb-1 ml-1">Profit %</label>
                            <input type="number" step="0.01" name="profit_percentage" value="<?php echo $row['profit_percentage']; ?>" class="neu-inset w-full md:w-40 px-4 py-2 text-slate-700 font-bold focus:outline-none rounded-lg text-sm bg-white/50">
                        </div>

                        <div class="pt-4 md:pt-0 w-full md:w-auto">
                            <button type="submit" name="update_financials" class="neu-btn w-full md:w-auto px-8 py-3 text-xs font-bold text-[#673ee5] uppercase tracking-wider">Update</button>
                        </div>
                    </form>
                </div>
                <?php endwhile; ?>
            </div>

        <!-- PAGE 3: DEPOSIT VERIFICATION -->
        <?php elseif($current_page == 'deposits'): ?>
            <div class="neu-card p-6">
                 <!-- Table Header -->
                <div class="grid grid-cols-12 gap-4 mb-4 px-4 text-xs font-bold text-slate-400 uppercase tracking-wider">
                    <div class="col-span-1">ID</div>
                    <div class="col-span-3">User</div>
                    <div class="col-span-2">Amount</div>
                    <div class="col-span-2">Proof</div>
                    <div class="col-span-2">Date</div>
                    <div class="col-span-2 text-right">Action</div>
                </div>

                <div class="space-y-4">
                    <?php 
                    $stmt = $pdo->query("SELECT d.*, u.email FROM deposits d JOIN users u ON d.user_id = u.id WHERE d.status = 'pending' ORDER BY d.created_at DESC");
                    while ($row = $stmt->fetch()): 
                    ?>
                    <div class="grid grid-cols-12 gap-4 items-center p-4 border-b border-slate-200/50 hover:bg-white/40 transition rounded-xl">
                        <div class="col-span-1 text-sm font-bold text-[#673ee5]">#<?php echo $row['id']; ?></div>
                        <div class="col-span-3">
                            <div class="font-bold text-slate-700 text-sm"><?php echo htmlspecialchars($row['email']); ?></div>
                        </div>
                        <div class="col-span-2 font-mono font-bold text-[#673ee5]">$<?php echo number_format($row['amount'], 2); ?></div>
                        <div class="col-span-2 text-[10px] text-slate-400 font-mono break-all bg-white/40 p-1 rounded"><?php echo $row['txn_hash']; ?></div>
                        <div class="col-span-2 text-xs text-slate-500"><?php echo date('M d, H:i', strtotime($row['created_at'])); ?></div>
                        
                        <div class="col-span-2 text-right flex justify-end space-x-2">
                             <form method="POST" onsubmit="return confirm('Approve?');">
                                <input type="hidden" name="deposit_id" value="<?php echo $row['id']; ?>">
                                <button type="submit" name="approve_deposit" class="neu-btn px-4 py-2 text-[10px] font-bold text-green-500 uppercase tracking-wider hover:bg-green-50">Approve</button>
                            </form>
                             <form method="POST" onsubmit="return confirm('Reject?');">
                                <input type="hidden" name="deposit_id" value="<?php echo $row['id']; ?>">
                                <button type="submit" name="reject_deposit" class="neu-btn px-4 py-2 text-[10px] font-bold text-red-500 uppercase tracking-wider hover:bg-red-50">Reject</button>
                            </form>
                        </div>
                    </div>
                    <?php endwhile; ?>
                    
                    <?php if($stmt->rowCount() == 0): ?>
                        <div class="p-8 text-center text-slate-400 text-sm font-bold uppercase">No pending deposits</div>
                    <?php endif; ?>
                </div>
            </div>

        <?php endif; ?>

    </main>
</div>

</body>
</html>
